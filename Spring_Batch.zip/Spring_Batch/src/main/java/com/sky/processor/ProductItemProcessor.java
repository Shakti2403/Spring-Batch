package com.sky.processor;

import org.springframework.batch.item.ItemProcessor;

import com.sky.domain.OutputProduct;
import com.sky.domain.Product;

public class ProductItemProcessor implements ItemProcessor<Product, OutputProduct>
{

	@Override
	public OutputProduct process(Product item) throws Exception {
		if(item.getPrice() > 50)
		{
			return new OutputProduct(item.getProductId(),item.getProductName(),item.getPrice());
		}
		else {
			return new OutputProduct();
		}
		
	}

}
